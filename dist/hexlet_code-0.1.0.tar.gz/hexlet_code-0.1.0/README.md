### Hexlet tests and linter status:
[![Actions Status](https://github.com/ElenaBronina/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ElenaBronina/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/cc6cb8f73e51c970c4d4/maintainability)](https://codeclimate.com/github/ElenaBronina/python-project-49/maintainability)

 https://asciinema.org/connect/eced8ae2-fae8-4486-a2ae-badfcc37758d