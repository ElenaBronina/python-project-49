#!/usr/bin/env python3
from games.calc import brain_calc


brain_calc()



